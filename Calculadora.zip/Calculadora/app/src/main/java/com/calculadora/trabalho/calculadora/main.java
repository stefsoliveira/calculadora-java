package com.calculadora.trabalho.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class main extends AppCompatActivity {

    Button
            button0,
            button1,
            button2,
            button3,
            button4,
            button5,
            button6,
            button7,
            button8,
            button9,
            dotbutton,
            equalbutton,
            sumbutton,
            subbutton,
            multibutton,
            divbutton,
            cleanbutton;
    EditText textOnClick,
             toConcatenate;
    double  num1,
            num2,
            result;
    String operator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button0 = (Button)findViewById(R.id.button0);
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);
        button4 = (Button)findViewById(R.id.button4);
        button5 = (Button)findViewById(R.id.button5);
        button6 = (Button)findViewById(R.id.button6);
        button7 = (Button)findViewById(R.id.button7);
        button8 = (Button)findViewById(R.id.button8);
        button9 = (Button)findViewById(R.id.button9);
        dotbutton = (Button)findViewById(R.id.dotbutton);
        equalbutton = (Button)findViewById(R.id.equalbutton);
        sumbutton = (Button)findViewById(R.id.sumbutton);
        subbutton = (Button)findViewById(R.id.subbutton);
        multibutton = (Button)findViewById(R.id.multibutton);
        divbutton = (Button)findViewById(R.id.divbutton);
        cleanbutton = (Button)findViewById(R.id.cleanbutton);
        textOnClick = (EditText)findViewById(R.id.textOnClick);

        dotbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + ".");
            }
        });
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "0");
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "1");
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "3");
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "4");
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "5");
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "6");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "7");
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "8");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                textOnClick.setText(toConcatenate.getText().toString() + "9");
            }
        });

        sumbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operator = "+";
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                num1 = Double.parseDouble(toConcatenate.getText().toString());
                textOnClick.setText("");
            }
        });
        subbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operator = "-";
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                num1 = Double.parseDouble(toConcatenate.getText().toString());
                textOnClick.setText("");
            }
        });
        multibutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operator = "*";
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                num1 = Double.parseDouble(toConcatenate.getText().toString());
                textOnClick.setText("");
            }
        });
        divbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operator = "/";
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                num1 = Double.parseDouble(toConcatenate.getText().toString());
                textOnClick.setText("");
            }
        });
        cleanbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1 = 0;
                num2 = 0;
                textOnClick.setText("");
            }
        });

        equalbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toConcatenate = (EditText)findViewById(R.id.textOnClick);
                num2 = Double.parseDouble(toConcatenate.getText().toString());
                //Sum
                if(operator.equals("+")){
                    textOnClick.setText("");
                    result = num1 + num2;
                }
                //Sub
                if(operator.equals("-")){
                    textOnClick.setText("");
                    result = num1 - num2;
                }
                //Mult
                if(operator.equals("*")){
                    textOnClick.setText("");
                    result = num1 * num2;
                }
                //Div
                if(operator.equals("/")){
                    textOnClick.setText("");
                    if(num2 != 0){
                        result = num1 / num2;
                    }else {
                        textOnClick.setText("Not a number");
                    }
                }
                textOnClick.setText(String.valueOf(result));
            }
        });
    }


}
